import asyncio
import time
from multiprocessing import Process
from model import ArticleInDB, initBeanie
import validators
import threading
import requests
import json
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from bs4 import BeautifulSoup as bs
import re
import redis
import os

REDIS_CONFIG = {
    "host": 'localhost',
    "port": 6379,
    "cache": 0,
}

# class Url(BaseModel):
#     link: str
#     createDate: Optional[datetime]
#     deep: int = 0
#     content: Optional[str] = ""
#
# class Inbox():
#     """
#     通过Redis的队列缓存所有待爬取URL
#     """
#     def __init__(self):
#         """
#         初始化Redis
#         """
#         self.r = redis.Redis(host=REDIS_CONFIG["host"], port=6379, db=REDIS_CONFIG["cache"])
#
#     def addUrl(self, url: Url):
#         """
#         向Redis的队列中添加url，并向Redis Hash中添加一个记录后续用于去重，防止循环爬取
#         :param url:URL地址
#         :return:
#         True:这是一个新的URL
#         Fasle:重复或无效URL
#         """
#         if self.checkUrls(url.link) is not None:
#             print("a")
#             if not self.r.hexists("URLSET", url.link):
#                 print("b")
#                 print("URL{}不存在".format(url.link))
#                 a = self.r.lpush("URLLIST", url.json())
#                 print("Add to URL List {}".format(a))
#                 a = self.r.hset("URLSET", url.link, url.json())
#                 print("Add to URL Set {}".format(a))
#                 return True
#             else:
#                 print("c")
#                 print("URL{}存在".format(url.link))
#                 return False
#         else:
#             print("d")
#             return False
#
#     def get(self):
#         """
#         从Redis的队列中pop出来一个URL对象
#         :return:
#         """
#         result = self.r.lpop("URLLIST")
#         print("1")
#         if result is not None:
#             print("2")
#             return Url(**json.loads(result))
#             # try:
#             #     a = Url(**json.loads(result))
#             #     print("2",a.link)
#             #     return Url(**json.loads(result))
#             # except:
#             #     print("3", a.link)
#             #     return None
#         return None
#
#     def checkUrls(self, url):
#         """
#         检查url是否合法
#         """
#         if validators.url(url):
#             return url
#         else:
#             return None
#
#
# class RequestThread(threading.Thread):
#     """
#     爬虫线程类
#     """
#
#     def __init__(self, inbox: Inbox,process):
#         super().__init__()
#         self.inbox = inbox
#         self.ProcessPipeline = process
#         # 成功链接和失败链接
#         self.success = 0
#         self.failed = 0
#         # 尝试次数
#         self.attempts = 3
#         # 超时时间
#         self.timeout = 5
#         # 重试策略
#         retry_strategy = Retry(
#             total=self.attempts,
#             status_forcelist=[429, 500, 502, 503, 504, 403],
#             method_whitelist=["HEAD", "GET", "OPTIONS"],
#         )
#         self.adapter = HTTPAdapter(max_retries=retry_strategy)
#
#
#     def run(self) -> None:
#         print("request线程启动")
#         s = requests.Session()
#         # s.mount("https://", self.adapter)
#         # s.mount("http://", self.adapter)
#         while True:
#             print("一次")
#             newURL = self.inbox.get()
#             print("拿到的URL是",newURL.link)
#             if newURL is not None:
#                 print("发送请求到",newURL.link)
#                 print(newURL.json())
#                 # response = s.get("https://learningenglish.voanews.com/",timeout=self.timeout)
#                 response = s.get(newURL.link, timeout=self.timeout)
#                 if response.status_code == 200:
#                     newURL.content = response.text
#                     self.ProcessPipeline.addPage(newURL)
#             else:
#                 print("URL空")
#             time.sleep(3)
#
#
#
# class VOAProcessPipeline(threading.Thread):
#     def __init__(self,inbox:Inbox):
#         super().__init__()
#         self.inbox = inbox
#         self.r = redis.Redis(host=REDIS_CONFIG["host"], port=6379, db=REDIS_CONFIG["cache"])
#
#     async def init_ODM(self):
#         file = open("mongodb_url", mode='r')
#         mongodb_url = file.readline()
#         file.close()
#         client = motor.motor_asyncio.AsyncIOMotorClient(mongodb_url)
#         await init_beanie(database=client.guguDB, document_models=[ArticleInDB])
#         print("Beanie已初始化")
#
#
#     @staticmethod
#     def checkIfFeedPage(text):
#         """
#         判断是否是VOA资讯页
#         """
#         # 方法1:根据是否存在"article-content"类
#         soup = bs(text, 'html.parser')
#         result = soup.find(id="article-content")
#         if result is not None:
#             return True, soup
#         else:
#             return False, soup
#
#
#     def addPage(self,urlWithContent:Url):
#         print("向PAGE2PROCESS添加",urlWithContent.json())
#         print("push result",str(self.r.lpush("PAGE2PROCESS",urlWithContent.json())))
#
#     def getPage(self):
#         page = self.r.lpop("PAGE2PROCESS")
#         if page is None:
#             return None
#         else:
#             try:
#                 return Url(**json.loads(page))
#             except:
#                 return None
#
#
#     def extractContent(self, text) -> Optional[dict[str, Union[str, Any]]]:
#         content = bs(text)
#         # 获取标题
#         title = content.find("meta", attrs={"name": "title"})
#         if title is not None:
#             title = title.attrs["content"]
#         else:
#             title = content.find("title").get_text()
#
#         result = content.find(id="article-content")
#         result = result.find("div", attrs={"class": "wsw"})
#
#         # 移除内嵌Youtube、Quiz、Audio
#         for item in result.find_all("div", attrs={"class": "wsw__embed"}):
#             item.extract()
#
#         # 移除超链接
#         for item in result.find_all("a", attrs={"class": "wsw__a"}):
#             item.unwrap()
#
#         # 移除特殊字体
#         for item in result.find_all("em"):
#             item.unwrap()
#
#         for item in result.find_all("strong"):
#             item.unwrap()
#
#         articleContent = ''
#
#         for paragraph in result.find_all("p"):
#             text: str = paragraph.text
#             text = text.replace("\n", " ")
#             text = re.sub(' +', ' ', text)
#             articleContent += text
#             articleContent += "\n"
#
#         print("title",title)
#         return {"title":title,"content":articleContent}
#
#
#     def extractAllLinks(self,url):
#         # 提取链接
#         p,rest = url.link.split("//")
#         domain = rest.split("/")[0]
#         # 过滤
#         links = []
#         for link in bs(url.content).findAll('a'):
#             link = link.get('href')
#             if list(link)[0] == '/':
#                 link = p+'//'+domain+link
#
#             links.append(link)
#
#         for link in links:
#             if not validators.url(link):
#                 self.inbox.addUrl(Url(link="link",deep=url.deep+1))
#                 print("Add Link")
#
#
#     def run(self):
#         while True:
#             page = self.getPage()
#             print("拿到的Page是{}".format(type(page)))
#             if page is not None:
#                 self.extractAllLinks(page)
#                 if self.checkIfFeedPage(page.content):
#                     result = self.extractContent(page.content)
#                     newArticle = ArticleInDB()
#                     newArticle.title = result['title']
#                     newArticle.content = result['content']
#                     try:
#                         newArticle.insert()
#                     except:
#                         pass
#             else:
#                 time.sleep(0.5)
#
#
#
#
# class SpiderEngine():
#     def __init__(self):
#         pass
#
# r = redis.Redis(host='localhost', port=6379, db=0)
# r.flushall()
#
# inbox = Inbox()
#
# result = inbox.addUrl(Url(**{"link":"https://learningenglish.voanews.com/z/952?p=2&d=1&m=5&y=2022"}))
# print("添加url{}".format(str(result)))
#
# pipe = VOAProcessPipeline(inbox)
# asyncio.run(pipe.init_ODM())
# request = RequestThread(inbox,pipe)
# pipe.start()
# request.start()


pool = redis.ConnectionPool(host='localhost', port=6379, db=0, decode_responses=True)
r = redis.Redis(connection_pool=pool)


async def charu(content):
    newArticle = ArticleInDB(**content)
    await newArticle.insert()


# lock = threading.Lock()
class Processor(threading.Thread):
    # PAGE的消费者 URL的生产者
    def __init__(self, domain="https://learningenglish.voanews.com"):
        super().__init__()
        self.r = redis.Redis(connection_pool=pool)
        self.domain = domain

    def isArticle(self, text):
        # 根据是否存在"article-content"类 判断是否是VOA的文章页面
        soup = bs(text, 'html.parser')
        result = soup.find(id="article-content")
        if result is not None:
            return True
        else:
            return False

    def addLinksInArticle2MQ(self, text):
        r = re.compile('(\\/a\\/.*).html')
        # r = re.compile(r'(\/[A-Za-z0-9]+\/.*).html')
        soup = bs(text, 'html.parser')
        for link in soup.find_all('a', href=True):
            # print("link:",type(link))
            result = r.search(link.get('href'))
            if result is not None:
                link = '' + self.domain + str(result.group())
                # print("页面存在URL{}".format(link))
                self.addNewUrl(link)

    def addNewUrl(self, url):
        # 通过集合"UNIURL"来去重,避免重复添加
        if self.r.sadd("UNIURL", url) == 1:
            # print("非重复URL 添加到队列")
            if (validators.url(url)):
                self.r.lpush("URL", str(url))
            else:
                # print("无效URL")
                pass
        else:
            # print("重复URL")
            pass

    def extractContent(self, text):
        content = bs(text)
        # 获取标题
        title = content.find("meta", attrs={"name": "title"})
        if title is not None:
            title = title.attrs["content"]
        else:
            title = content.find("title").get_text()

        result = content.find(id="article-content")
        result = result.find("div", attrs={"class": "wsw"})

        # 移除内嵌Youtube、Quiz、Audio
        for item in result.find_all("div", attrs={"class": "wsw__embed"}):
            item.extract()

        # 移除超链接
        for item in result.find_all("a", attrs={"class": "wsw__a"}):
            item.unwrap()

        # 移除特殊字体
        for item in result.find_all("em"):
            item.unwrap()

        for item in result.find_all("strong"):
            item.unwrap()

        articleContent = ''

        for paragraph in result.find_all("p"):
            text: str = paragraph.text
            text = text.replace("\n", " ")
            text = re.sub(' +', ' ', text)
            articleContent += text
            articleContent += "\n"
        return {"title": title, "content": articleContent}

    def run(self) -> None:
        print("Processor启动")
        count = 0
        # 进行两个工作：提取文章、提取url
        while True:
            result = self.r.lpop("PAGE")
            if result is None:
                # print("啥PAGE也没取到")
                time.sleep(0.5)
            else:
                # print("取到PAGE")
                if self.isArticle(result):
                    # print("提取到内容:")
                    article = self.extractContent(result)
                    self.r.lpush("ARTICLE", ArticleInDB(**article).json())
                self.addLinksInArticle2MQ(result)


class RequestThread(threading.Thread):
    # URL的消费者 PAGE的生产者
    def __init__(self):
        super().__init__()
        self.r = redis.Redis(connection_pool=pool)
        # 成功链接和失败链接
        self.success = 0
        self.failed = 0
        # 尝试次数
        self.attempts = 3
        # 超时时间
        self.timeout = 5
        # 重试策略
        retry_strategy = Retry(
            total=self.attempts,
            status_forcelist=[429, 500, 502, 503, 504, 403],
        )
        self.adapter = HTTPAdapter(max_retries=retry_strategy)

    def run(self) -> None:
        print("[Request]request线程启动")
        s = requests.Session()
        count = 0
        while True:
            url = self.r.lpop("URL")
            if url is not None:
                count += 1
                print("[Request]Get {}".format(count), url)

                response = s.get(url, timeout=self.timeout)
                if response.status_code == 200:
                    print("[Request]URL {} 200".format(count))
                    # print("添加内容到PAGE队列")
                    self.r.lpush("PAGE", response.content)
                else:
                    print("[Request]URL {} Error".format(count))
            else:
                # print("没有拿到URL 睡1s")
                time.sleep(1)
            time.sleep(1)


r.set("stop", "0")


# 子进程要执行的代码
async def inserArticle(name):
    await initBeanie("mongodb+srv://gugubird:awePoHGNbUvAAXRd@cluster0.bb2bt.mongodb.net/?retryWrites=true&w=majority")
    print('Child process will start.')
    r = redis.Redis(connection_pool=pool)
    count = 0
    while r["stop"] == '0':
        result = r.lpop("ARTICLE")
        if result is not None:
            count += 1
            # print("[insert][{}]Get {}".format(name,count))
            try:
                newArticle = ArticleInDB(**json.loads(result))
                await newArticle.insert()
                os.system("clear")
                print("[insert][{}]第{}篇入库成功.\n[title]{}".format(name, count, newArticle.title))
            except:
                print("[insert][{}]插入第{}入库失败.".format(name, count))
                continue
        else:
            # print("睡眠")
            time.sleep(1)


def run_proc(name):
    print('入库进程启动\tPID:{}'.format(os.getpid()))
    if os.getpid() > 0:
        asyncio.new_event_loop().run_until_complete(inserArticle(name))


if __name__ == '__main__':
    client = asyncio.run(
        initBeanie("mongodb+srv://gugubird:awePoHGNbUvAAXRd@cluster0.bb2bt.mongodb.net/?retryWrites=true&w=majority"))
    # for i in range(10):

    a = [RequestThread() for i in range(30)]
    b = [Processor() for i in range(3)]

    # 种子URL
    for i in range(2020, 2023):
        for j in range(1, 13):
            for k in range(1, 30):
                b[0].addNewUrl("https://learningenglish.voanews.com/z/952/{}/{}/{}".format(i, j, k))
    # 种子URL添加完成

    for item in a:
        item.start()

    for item in b:
        item.start()

    p1 = Process(target=run_proc, args=("1",))
    p2 = Process(target=run_proc, args=("2",))
    p1.start()
    p2.start()
    p1.join()
    p2.join()

#
# class Proxy(BaseModel):
#     localPort:int
#     url:str
# from multiprocessing import Pool
# class ProxyPool():
#     def __init__(self):
#         self.pool = Pool(100)
#         self.process = []
#         self.trojanUrlList = []
#         self.localPortStart = 1234
#         self.loadProxiesUrl()
#
#     def loadProxiesUrl(self):
#         try:
#             self.trojanUrlList = str(open("proxies", mode='r').read()).split("\n")
#         except:
#             print("加载代理失败")
#
#
#     def getNewPort(self):
#         self.localPortStart += 1
#         if self.isPortInUse(self.localPortStart):
#             return self.getNewPort()
#         else:
#             return self.localPortStart
#
#
#
#     def checkActive(self,proxy:Proxy):
#         url = 'https://httpbin.org/ip'
#         proxies = {
#             "http": 'socks5://127.0.0.1:{}'.format(proxy.localPort),
#             "https": 'socks5://127.0.0.1:{}'.format(proxy.localPort)
#         }
#         try:
#             response = requests.get(url, proxies=proxies)
#             if response.status_code == 200:
#                 print("代理IP是:",response.text)
#                 return True
#             else:
#                 return False
#         except:
#             return False
#
#
#     def isPortInUse(self,port):
#         import socket
#         s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#         try:
#             s.connect(("127.0.0.1", int(port)))
#             s.shutdown(2)
#             return True
#         except:
#             return False
#
#     def start(self,url,port):
#         command = r"""./trojan-go -url "{}" -url-option listen=127.0.0.1:{}""".format(url,port)
#         p = os.popen(command)
#         print("代理启动中...")
#         time.sleep(5)
#         print("1")
#         output:str = p.readlines()
#
#         if "ERROR" in output:
#             print("2")
#             return None
#         elif "listening" in output:
#             return p
#         else:
#             print("3")
#             return None
#
#
#     import random
#     # def getAProxy(self):
#     #     # try:
#     #     url = self.trojanUrlList.pop()
#     #     port = self.getNewPort()
#     #     subprocess = self.start(url,port)
#     #     if subprocess is not None:
#     #         self.process.append((Proxy(url=url,localPort=port),subprocess))
#     #         return Proxy(url=url,localPort=port)
#     #     else:
#     #         return None
#         # except IndexError:
#         #     print("代理池用尽，复用已启动代理")
#         #     if self.process != []:
#         #         random.choice(self.process)
#         #     else:
#         #         None
#         # except:
#         #     print("未知错误，复用已启动代理")
#         #     if self.process != []:
#         #         random.choice(self.process)
#         #     else:
#         #         return None
# a = ProxyPool()
# print(a.getAProxy())
