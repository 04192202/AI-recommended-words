from model import *

from fastapi import FastAPI
from auth import appLogin
from register import appRegister
from article import appArticle
from wordLookup import appLookup, initializeDict2Redis
from user import appUser
from SM2 import appSM2
from fastapi.middleware.cors import CORSMiddleware

# 创建APP
app = FastAPI()

# 路由
app.include_router(appLogin, prefix='/auth', tags=["Token相关"])
app.include_router(appRegister, prefix='/register', tags=["用户注册"])
app.include_router(appArticle, prefix='/article', tags=["文章操作"])
app.include_router(appUser, prefix='/user', tags=["用户操作"])
app.include_router(appLookup, prefix='/word', tags=["查词"])
app.include_router(appSM2,prefix='/sm2',tags=["记忆算法"])

origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    # "*"
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    # ""
]


app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_origin_regex="[a-zA-z]+://[^\s]*",
    allow_headers=["*"],
)



@app.on_event("startup")
async def start():
    file = open("mongodb_url", mode='r')
    mongodb_url = file.readline()
    file.close()
    # initializeDict2Redis()
    await initBeanie(mongodb_url)
