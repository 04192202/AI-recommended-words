import asyncio
import json

from wordcloud import WordCloud
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans


import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from model import ArticleInDB
from article import get_article_backend
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import redis
pool = redis.ConnectionPool(host='localhost', port=6379, db=0, decode_responses=True)

async def kmeansTraining():
    print("[推荐系统]弱关联文章训练")
    await initBeanie("mongodb+srv://gugubird:awePoHGNbUvAAXRd@cluster0.bb2bt.mongodb.net/?retryWrites=true&w=majority")
    r = redis.Redis(connection_pool=pool)
    print("[推荐系统]正在下载数据集")
    data = await ArticleInDB.find_all().to_list()
    print("[推荐系统]数据集下载完成")
    datasets = {
        "title": [],
        "content": []
    }
    for art in data:
        datasets["title"].append(art.title)
        datasets["content"].append(art.content)

    print("[推荐系统]正在计算TF-IDF矩阵")
    tf = TfidfVectorizer(analyzer='word', ngram_range=(1, 2), min_df=0, stop_words='english', max_features=500)
    tfidf_matrix = tf.fit_transform(datasets["content"])
    print("[推荐系统]聚类计算开始")
    kmeans = KMeans(n_clusters=9)
    kmeans.fit(tfidf_matrix)
    # 打印出各个族的中心点
    print(kmeans.cluster_centers_)
    # 添加到Redis
    for index, label in enumerate(kmeans.labels_, 0):
        print("index: {}, label: {}".format(index, label))
        r.sadd("TAG{}".format(label),str(data[index].json()))
        r.hset("ARTICLELABEL",str(data[index].id),str(label))

    # 样本距其最近的聚类中心的平方距离之和，用来评判分类的准确度，值越小越好
    # k-means的超参数n_clusters可以通过该值来评估
    print("inertia: {}".format(kmeans.inertia_))


    tsne = TSNE(n_components=2)
    decomposition_data = tsne.fit_transform(tfidf_matrix)

    x = []
    y = []

    for i in decomposition_data:
        x.append(i[0])
        y.append(i[1])

    fig = plt.figure(figsize=(10, 10))
    ax = plt.axes()
    plt.scatter(x, y, c=kmeans.labels_, marker="x")
    plt.xticks(())
    plt.yticks(())


    # 降维到2维的聚类结果的可视化
    plt.savefig('./result.png')
    print("[推荐系统]文章标签训练完成")


async def generateWordCloudByTFIDF():
    await initBeanie("mongodb+srv://gugubird:awePoHGNbUvAAXRd@cluster0.bb2bt.mongodb.net/?retryWrites=true&w=majority")
    print("[推荐系统]聚类可视化")
    r = redis.Redis(connection_pool=pool)
    image = []
    for i in range(9):
        result = r.smembers("TAG{}".format(i))
        print("TAG{}".format(i))
        datasets = {
            "title": [],
            "content": []
        }
        text = ""
        for item in result:
            a = ArticleInDB(**json.loads(item))
            datasets["title"].append(a.title)
            text += str(a.content)

        wordcloud = WordCloud(width=3000, height=2000, background_color='white')

        wordcloud.generate_from_text(text)
        image.append(wordcloud)

    return image

async def visualize():
    images = await generateWordCloudByTFIDF()
    fig = plt.figure()
    for i,image in enumerate(images):
        fig.add_subplot(3, 3, i+1)
        plt.imshow(image)
        plt.axis('off')
        plt.title("Cluster {}".format(i+1))
    plt.show()

from model import initBeanie

# asyncio.run(kmeansTraining())
asyncio.run(visualize())