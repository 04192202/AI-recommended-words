from fastapi import APIRouter
import redis
import csv
from model import Word
import json
import pyttsx3
import base64

appLookup = APIRouter()
REDIS_CONFIG = {  # 设置
    "host": 'localhost',
    "port": 6379,
    "cache": 0,
    "word": 1
}

r = redis.Redis(host=REDIS_CONFIG["host"], port=REDIS_CONFIG["port"], db=REDIS_CONFIG["word"])


def initializeDict2Redis():
    """
    将字典内容存进redis
    """
    with open("./ecdict.csv", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        count = 0
        for row in reader:
            try:
                newWord = Word(**row)
                count += r.hset("dictionary", newWord.word, newWord.json())
                print(count)
            except:
                pass


@appLookup.get("/{word_lookup}/lookup")
async def lookup(word_lookup):
    """
    从redis中根据key查询
    """
    result = r.hget("dictionary", word_lookup)
    if result is not None:
        result = json.loads(result)
        result["status"] = 'success'
        return result
    else:
        return {'status': 'failed'}


@appLookup.get("/{word_lookup}/audio")
async def audio(word_lookup):
    """
    生成指定单词的音频文件
    """
    try:
        engine = pyttsx3.init()  # 创建对象

        # 语音设置
        engine.setProperty('rate', 150)  # 语音速率
        engine.setProperty('volume', 1.0)  # 语音音量
        voices = engine.getProperty('voices')  # 声音详细信息
        engine.setProperty('voice', voices[1].id)  # 设置当前语音声音,英文

        # 生成音频文件
        engine.save_to_file(word_lookup, 'temp.mp3')
        engine.runAndWait()

        # 编码为Base64
        file1 = open("temp.mp3", "rb").read()
        text1 = base64.b64encode(file1)

        return {'status': 'success', 'audio': str(text1)}

    except:
        return {'status': 'failed'}
