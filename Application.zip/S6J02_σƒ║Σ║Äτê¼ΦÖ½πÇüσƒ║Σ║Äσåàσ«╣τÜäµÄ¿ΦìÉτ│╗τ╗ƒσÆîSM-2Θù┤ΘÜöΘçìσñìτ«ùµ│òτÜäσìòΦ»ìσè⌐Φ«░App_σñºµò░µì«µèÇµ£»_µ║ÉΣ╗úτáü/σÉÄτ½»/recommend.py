import asyncio

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from model import *


async def recommend_train():
    """
    基于内容的推荐系统
    """
    print("[内容推荐系统]正在从数据库下载文章。注意，如果下行网速长时间较低并还未下载完成请重新启动脚本")
    tf = TfidfVectorizer(analyzer='word', ngram_range=(1, 2), min_df=0, stop_words='english', max_features=500)
    dataInDB = ArticleInDB.find_all()
    data = await dataInDB.to_list()
    # print(await dataInDB.find(ArticleInDB.title == "").to_list())
    print("[内容推荐系统]文章下载完成，开始分词")

    datasets = {
        "title": [],
        "content": []
    }
    for art in data:
        datasets["title"].append(art.title)
        datasets["content"].append(art.content)

    # print(datasets)
    tfidf_matrix = tf.fit_transform(datasets["content"])
    print("[内容推荐系统]分词训练完成，开始训练内容相似度")
    cosine_similarities = linear_kernel(tfidf_matrix, tfidf_matrix)
    print("[内容推荐系统]内容相似度训练完成")

    upload_list = []
    for idx, _ in enumerate(datasets["title"]):
        print("[内容推荐系统]相似度排序进度:", idx, "/", len(datasets["title"]))
        similar_indices = cosine_similarities[idx].argsort()[:-6:-1]
        similar_items = [(cosine_similarities[idx][i], datasets['title'][i]) for i in similar_indices]
        upload_list.append(similar_items)
        # print(similar_items[0][1], similar_items[1:])
        # print(similar_items[0][1], [i[1] for i in similar_items[1:]])

    print("[内容推荐系统]相似度排序完成，开始处理数据")
    art_ptr_list = []
    for idx, upload in enumerate(upload_list):
        print("[内容推荐系统]数据处理进度:", idx, "/", len(upload_list))
        # art_ptr = await get_article_backend(upload[0][1])
        art_ptr = dataInDB.find(ArticleInDB.title == upload[0][1])
        art_ptr.inc({ArticleInDB.recommend: [i[1] for i in upload[1:5]]})
    #     art_ptr.recommend = [i[1] for i in upload[1:5]]
    #     art_ptr_list.append(art_ptr)
    #
    # print("[内容推荐系统]处理数据完成，开始上传到数据库")
    # for idx, art_ptr in enumerate(art_ptr_list):
    #     print("[内容推荐系统]相似度上传进度:", idx, "/", len(upload_list))
    #     art_ptr.save()
    #
    # await art_ptr_list[0].save()
    print("[内容推荐系统]全部完成")


async def recommend_train_LDA():
    tf = TfidfVectorizer(analyzer='word', ngram_range=(1, 2), min_df=0, stop_words='english', max_features=8)
    data = await ArticleInDB.find_all().to_list()

    datasets = {
        "title": [],
        "content": []
    }
    for art in data:
        datasets["title"].append(art.title)
        datasets["content"].append(art.content)

    # print(datasets)
    tfidf_matrix = tf.fit_transform(datasets["content"])

    X = np.array(tfidf_matrix.toarray())
    Y = np.array([1, 1, 2, 2, 3, 3])
    print(X)
    print(Y)

    lda = LDA()
    lda.fit(X, Y)

    print(lda.predict([X[0]]))
    # print(lda.solver)
    # print(lda.shrinkage)

    # for title_index, vs in enumerate(lda.solver):
    #     print(title_index, datasets["title"][title_index])
    #     for i, v in enumerate(vs):
    #         if v != 0:
    #             print(lda.shrinkage[i], v)


async def recommend_main():
    file = open("mongodb_url", mode='r')
    mongodb_url = file.readline()
    file.close()
    await initBeanie(mongodb_url)
    await recommend_train()


if __name__ == '__main__':
    asyncio.run(recommend_main())
