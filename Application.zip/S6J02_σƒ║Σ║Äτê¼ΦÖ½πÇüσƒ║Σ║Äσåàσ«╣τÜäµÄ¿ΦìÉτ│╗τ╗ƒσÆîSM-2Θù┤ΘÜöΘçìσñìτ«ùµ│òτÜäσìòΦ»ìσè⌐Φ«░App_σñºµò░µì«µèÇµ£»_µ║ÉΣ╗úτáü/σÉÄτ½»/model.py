import datetime

from pydantic import BaseModel
from typing import Union, List
from beanie import init_beanie, Document, Link
import pymongo
import motor.motor_asyncio


class Token(BaseModel):
    """
    Token类
    """
    access_token: str
    token_type: str
    expired_time: int


class TokenData(BaseModel):
    username: Union[str, None] = None


# class WordInDB(Document):
#     """
#     数据库单词类
#     """
#     content: str
#     definition: str
#     pron: Union[str, None] = None
#
#     class Settings:
#         # 表名称
#         name = "word"
#         # 添加索引
#         indexes = [
#             [("content", pymongo.TEXT)]
#         ]


class Word(BaseModel):
    """
    单词类
    """
    word: str = ''
    phonetic: str = ''
    definition: str = ''
    translation: str = ''
    pos: str = ''
    collins: str = ''
    oxford: str = ''
    tag: str = ''
    bnc: str = ''
    frq: str = ''
    exchange: str = ''
    detail: str = ''
    audio: str = ''


class UserWordInDB(Document):
    """
    数据库中的 用户选择的单词类，作为用户的学习记录
    """
    word: str
    EFactor: float = 2.5
    # 日期队列开始计算的日期
    initDate: datetime.datetime = datetime.datetime.now()
    # 初始为当天和六天后
    DateSeq: List[datetime.datetime] = [datetime.datetime.now(),datetime.datetime.now() + datetime.timedelta(days=6)]

    class Settings:
        # 表名称
        name = "UserWord"


class User(BaseModel):
    """
    用户类
    """
    username: str
    email: Union[str, None] = None
    selected_word: List[Link[UserWordInDB]] = []
    selected_article: List[str] = []  # title


class UserInDB(Document):
    """
    数据库中的用户类
    """
    username: str
    email: Union[str, None] = None
    selected_word: List[Link[UserWordInDB]] = []
    selected_article: List[str] = []  # title
    hashed_password: str

    class Settings:
        # 表名称
        name = "user"
        # 添加索引
        indexes = [
            [("name", pymongo.TEXT)]
        ]


class ArticleInDB(Document):
    """
    数据库中的文章类
    """
    title: str
    content: str
    categories: List[str] = []
    recommend: List[str] = []

    class Settings:
        # 表名称
        name = "article"
        # 添加索引
        indexes = [
            [("title", pymongo.TEXT)]
        ]


class ArticleImage(Document):
    """
    文章对应图片存储
    """
    title: str
    img: str

    class Settings:
        # 表名称
        name = "img"
        # 添加索引
        indexes = [
            [("title", pymongo.TEXT)]
        ]

__DBRefsCleaner: any


def DBRefsCleaner(table_name):
    global __DBRefsCleaner
    return __DBRefsCleaner[table_name]


# 创建数据库、collection
async def initBeanie(url: str):
    client = motor.motor_asyncio.AsyncIOMotorClient(url)
    await init_beanie(database=client.guguDB, document_models=[UserInDB, ArticleInDB, UserWordInDB,ArticleImage])
    global __DBRefsCleaner
    __DBRefsCleaner = pymongo.MongoClient(url)["guguDB"]
    print("Beanie已初始化")
