#guback
## 使用conda进行环境管理
安装conda后，从shell下新建环境：
```
conda create --name guback
```
进入环境：
```
conda activate guback
```
进入环境后，提示符前应出现环境名称 e.g.：
```
(guback)timwong ~:
```

## 安装相关依赖
```
pip install fastapi
pip install uvicorn
pip install beanie
pip install passlib 
pip install python-jose
pip install scikit-learn
pip install validators
pip install beautifulsoup4
pip install redis
pip install bcrypt
pip install python-multipart
pip install pyttsx3
python -m pip install "pymongo[srv]
```

## 配置MongoDB服务器地址：
在项目文件夹内新建文件`.gitignore`，内容为：
```
mongodb_url
```
在项目文件夹内新建文件`mongodb_url`，内容为服务器URL地址

## 启动后端：
```
uvicorn main:app --reload
```
## 文档：
Beanie ODM：https://roman-right.github.io/beanie/

FastAPI：https://fastapi.tiangolo.com/zh/

Pydantic：https://pydantic-docs.helpmanual.io/

Pydantic JB插件:https://plugins.jetbrains.com/plugin/12861-pydantic

Requests: https://requests.readthedocs.io/projects/cn/zh_CN/latest/
