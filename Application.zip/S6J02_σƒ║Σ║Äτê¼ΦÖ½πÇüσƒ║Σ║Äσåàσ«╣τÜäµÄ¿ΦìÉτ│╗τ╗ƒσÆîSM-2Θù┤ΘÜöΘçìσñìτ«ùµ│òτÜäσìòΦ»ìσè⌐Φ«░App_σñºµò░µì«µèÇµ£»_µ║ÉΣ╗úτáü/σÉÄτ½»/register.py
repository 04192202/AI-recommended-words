from fastapi import APIRouter, status, HTTPException
from pydantic import BaseModel
from typing import Union

from model import UserInDB
from utility import hash_password


class RegRequest(BaseModel):
    username: str
    email: Union[str, None] = None
    raw_password: str


class RegResponse(BaseModel):
    result: bool
    message: str


appRegister = APIRouter()


@appRegister.post("/register", response_model=RegResponse)
async def register_new_user(regRequest: Union[RegRequest, None] = None):
    # 检查格式
    if regRequest is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=RegResponse(result=False, message="注册请求格式错误").json(),
        )

    try:
        # 检查是否已经注册
        result = await UserInDB.find_one(UserInDB.username == regRequest.username)
        if result is not None:
            return RegResponse(result=False, message="该用户已经被注册")
        # 新建Document对象
        newUser = UserInDB(**{"username": regRequest.username,
                              "email": regRequest.email,
                              "hashed_password": hash_password(regRequest.raw_password),
                              })
        # 插入
        await newUser.insert()
        # 插入成功
        return RegResponse(result=True, message="注册成功")
    except Exception as e:
        print("Exception: ", e)  # debug
        # 失败
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=RegResponse(result=False, message="服务器错误").json(),
        )


@appRegister.post("/updateProfile", response_model=RegResponse)
async def register_new_user():
    try:
        # 更新个人信息
        pass
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=RegResponse(result=False, message="注册失败").json(),
        )

# @appRegister.post("/forgot", response_model=RegResponse)
# async def register_new_user():
#     try:
#         # 忘记密码
#         pass
#     except:
#         raise HTTPException(
#             status_code=status.HTTP_400_BAD_REQUEST,
#             detail=RegResponse(result=False,message="注册失败").json(),
#         )
