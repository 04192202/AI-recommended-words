import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from auth import oauth2_scheme, get_current_user
from model import UserWordInDB
from user import get_word_backend

appSM2 = APIRouter()


class WordUpdateResponse(BaseModel):
    result: bool
    message: str


@appSM2.post("/{word}/updateEFactor/{quality}", response_model=WordUpdateResponse)
async def update_word_e_factor(word: str, quality: int, token: str = Depends(oauth2_scheme)):
    """
    更新单个单词的背诵情况
    """

    user = await get_current_user(token)
    userWord = get_word_backend(user,word)

    """
    If the quality response was lower than 3 then start repetitions for the item from the beginning without changing the E-Factor
    (i.e. use intervals I(1), I(2) etc. as if the item was memorized anew).
    """
    if quality < 3:
        # 如果quality较差，重置第一天为次日，E-Factor不变
        userWord.initDate = datetime.datetime.now() + datetime.timedelta(days=1)
        return WordUpdateResponse(**{
            "result":True,
            "message":"Success",
        })

    # 根据Quality更新E-Factor
    """
    5 - perfect response
    4 - correct response after a hesitation
    3 - correct response recalled with serious difficulty
    2 - incorrect response; where the correct one seemed easy to recall
    1 - incorrect response; the correct one remembered
    0 - complete blackout.
    
    EF':=EF+(0.1-(5-q)*(0.08+(5-q)*0.02))
    where:
    EF' - new value of the E-Factor,
    EF - old value of the E-Factor,
    q - quality of the response in the 0-5 grade scale.
    If EF is less than 1.3 then let EF be 1.3.
    """

    userWord.EFactor = userWord.EFactor + (0.1-(5-quality)*(0.08+(5-quality)*0.02))
    userWord.EFactor = max(userWord.EFactor, 1.3)

    # TODO 把更新后的单词写到UserInDB中
    try:
        await UserWordInDB.save()
        return WordUpdateResponse(**{
            "result": True,
            "message": "Success",
        })
    except Exception as e:
        # print("Exception: ", e)  # debug
        return WordUpdateResponse(**{
            "result": False,
            "message": "Failed",
        })


