from typing import List
from beanie import WriteRules, DeleteRules
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic.main import BaseModel
from starlette import status
from auth import oauth2_scheme, get_current_user
from model import UserWordInDB, UserInDB, ArticleInDB, DBRefsCleaner
from wordLookup import r

appUser = APIRouter()


class UserWordsResponse(BaseModel):
    result: bool
    message: str
    words: List[dict] = None


class UserArticlesResponse(BaseModel):
    result: bool
    message: str
    articles: List[str] = None


async def add_word_backend(userInDB: UserInDB, word: str):
    """
    在后端为用户添加选择的单词（参数为单词字符串）
    :param userInDB: 用户对象
    :param word: 单词
    :return: bool
    """
    result = r.hget("dictionary", word)
    if result is not None:
        if not await get_word_backend(userInDB, word):
            wordInDB = UserWordInDB(**{"word": word})
            await wordInDB.insert()
            userInDB.selected_word.append(wordInDB)
            await userInDB.save(link_rule=WriteRules.WRITE)
            # print("已添加：", await get_word_backend(userInDB, word))
            return True
    return False


async def get_word_backend(userInDB: UserInDB, word: str):
    """
    根据一个单词字符串在后端获取用户选择的这个单词（返回单词对象，包含sm2算法信息等）
    :param userInDB: 用户对象
    :param word: 单词字符串
    :return: UserWordInDB | None
    """
    myUserInDB = await UserInDB.find_one(UserInDB.username == userInDB.username, fetch_links=True)
    for w in myUserInDB.selected_word:
        if w.word == word:
            return w


async def get_words_backend(userInDB: UserInDB):
    """
    在后端获取用户选择的单词（返回单词对象列表，包含sm2算法信息等）
    :param userInDB: 用户对象
    :return: [words]
    """
    myUserInDB = await UserInDB.find_one(UserInDB.username == userInDB.username, fetch_links=True)
    words = []
    for word in myUserInDB.selected_word:
        words.append({"word": word.word, "EFactor": word.EFactor, "initDate": word.initDate, "DateSeq": word.DateSeq})
    return words


async def delete_word_backend(userInDB: UserInDB, word: str):
    """
    在后端删除用户选择的单词（参数为单词字符串）
    :param userInDB: 用户对象
    :param word: 单词
    :return: bool
    """
    result = r.hget("dictionary", word)
    if result is not None:
        myUserInDB = await UserInDB.find_one(UserInDB.username == userInDB.username, fetch_links=True)
        for index, w in enumerate(myUserInDB.selected_word):
            if w.word == word:
                # await UserWordInDB.find_one(UserWordInDB.id == w.id).delete()  # 删UserWordInDB
                await w.delete(link_rule=DeleteRules.DELETE_LINKS)  # 删UserWordInDB
                indexInfo = "selected_word." + str(index)
                magicValue = "233"
                DBRefsCleaner("user").update_one({"_id": ObjectId(str(myUserInDB.id))},
                                                 {"$set": {indexInfo: magicValue}})
                DBRefsCleaner("user").update_one({"_id": ObjectId(str(myUserInDB.id))},
                                                 {"$pull": {"selected_word": {"$in": [magicValue]}}})
                return True
    return False


@appUser.post("/add_word", response_model=UserWordsResponse)
async def add_word(token: str = Depends(oauth2_scheme), word: str = "单词默认值"):
    """
    添加用户选择的单词（参数为单词字符串）
    """
    userInDB = await get_current_user(token)
    try:
        result = await add_word_backend(userInDB, word)
        if result:
            return UserWordsResponse(result=True, message="Addition succeeded")
        else:
            return UserWordsResponse(result=False, message="Addition failed")
    except Exception:
        # traceback.print_exc()  # debug
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@appUser.post("/get_words", response_model=UserWordsResponse)
async def get_words(token: str = Depends(oauth2_scheme)):
    """
    获取用户选择的单词（返回单词对象列表，包含sm2算法信息等）
    """
    userInDB = await get_current_user(token)
    try:
        words = await get_words_backend(userInDB)
        return UserWordsResponse(result=True, message="Query succeeded", words=words)
    except Exception:
        # traceback.print_exc()  # debug
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@appUser.post("/delete_word", response_model=UserWordsResponse)
async def delete_word(token: str = Depends(oauth2_scheme), word: str = "单词默认值"):
    """
    删除用户选择的单词（参数为单词字符串）
    """
    userInDB = await get_current_user(token)
    try:
        result = await delete_word_backend(userInDB, word)
        if result:
            return UserWordsResponse(result=True, message="Deletion succeeded")
        else:
            return UserWordsResponse(result=False, message="Deletion failed")
    except Exception:
        # traceback.print_exc()  # debug
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


async def add_article_backend(userInDB: UserInDB, title: str):
    """
    在后端添加用户选择的文章（参数为文章标题字符串）
    :param userInDB: 用户对象
    :param title:  文章标题
    :return: bool
    """
    result = await ArticleInDB.find_one(ArticleInDB.title == title)
    if result is not None:
        if title not in await get_articles_backend(userInDB):
            userInDB.selected_article.append(title)
            await userInDB.save()
            return True
    return False


async def get_articles_backend(userInDB: UserInDB):
    """
    在后端获取用户选择过的文章（返回文章标题字符串列表）
    :param userInDB: 用户对象
    :return: [articles]
    """
    return userInDB.selected_article


async def delete_article_backend(userInDB: UserInDB, title: str):
    """
    在后端删除用户选择过的文章（参数为文章标题字符串）
    :param userInDB: 用户对象
    :param title: 文章标题
    :return: bool
    """
    if title in userInDB.selected_article:
        for index, _ in enumerate(userInDB.selected_article):
            if userInDB.selected_article[index] == title:
                indexInfo = "selected_article." + str(index)
                magicValue = "233"
                DBRefsCleaner("user").update_one({"_id": ObjectId(str(userInDB.id))},
                                                 {"$set": {indexInfo: magicValue}})
                DBRefsCleaner("user").update_one({"_id": ObjectId(str(userInDB.id))},
                                                 {"$pull": {"selected_article": {"$in": [magicValue]}}})
                return True
    return False


@appUser.post("/add_article", response_model=UserArticlesResponse)
async def add_article(token: str = Depends(oauth2_scheme), title: str = "标题默认值"):
    """
    添加用户选择的文章（参数为文章标题字符串）
    """
    userInDB = await get_current_user(token)
    try:
        result = await add_article_backend(userInDB, title)
        if result:
            return UserArticlesResponse(result=True, message="Addition succeeded")
        else:
            return UserArticlesResponse(result=False, message="Addition failed")
    except Exception:
        # traceback.print_exc()  # debug
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@appUser.post("/get_articles", response_model=UserArticlesResponse)
async def get_articles(token: str = Depends(oauth2_scheme)):
    """
    获取用户选择过的文章（返回文章标题字符串列表）
    得到文章标题后使用`/article/get_article_info`接口获取文章详细信息
    """
    userInDB = await get_current_user(token)
    try:
        articles = await get_articles_backend(userInDB)
        return UserArticlesResponse(result=True, message="Query succeeded", articles=articles)
    except Exception:
        # traceback.print_exc()  # debug
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


@appUser.post("/delete_article", response_model=UserArticlesResponse)
async def delete_article(token: str = Depends(oauth2_scheme), title: str = "标题默认值"):
    """
    删除用户选择的文章（参数为文章标题字符串）
    """
    userInDB = await get_current_user(token)
    try:
        result = await delete_article_backend(userInDB, title)
        if result:
            return UserArticlesResponse(result=True, message="Deletion succeeded")
        else:
            return UserArticlesResponse(result=False, message="Deletion failed")
    except Exception:
        # traceback.print_exc()  # debug
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)
