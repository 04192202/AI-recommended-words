from passlib.context import CryptContext


def hash_password(rawPassword: str):
    """
    :param rawPassword:str 原始密码
    :return:
        成功:hash后的密码
        失败:None
    """
    try:
        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        return pwd_context.hash(rawPassword)
    except:
        return None
